package com.example.service.lecture

import android.content.Context
import android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
import android.util.Log
import androidx.work.*
import kotlinx.coroutines.delay

abstract class SimpleWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    // if expedited
    override suspend fun getForegroundInfo(): ForegroundInfo {
        return ForegroundInfo(
            /* notificationId = */ 1,
            /* notification = */
            createNotification(applicationContext, "BaseWorker", "Im so important")
        )
    }

    override suspend fun doWork(): Result {
        val msg = inputData.getString(MSG_KEY).orEmpty()
        setForegroundAsync(
            ForegroundInfo(
                /* notificationId = */ 1,
                /* notification = */
                createNotification(applicationContext, "BaseWorker", msg),
                FOREGROUND_SERVICE_TYPE_MANIFEST // FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        )
        return Result.success()
    }

    companion object {
        private const val MSG_KEY = "MSG_KEY"

        fun getWorkData(msg: String): Data {
            return workDataOf(
                MSG_KEY to msg,
            )
        }
    }
}