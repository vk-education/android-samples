package com.vk.vkeduconcurrency.sync

import java.util.concurrent.Semaphore

fun main() {
    val parkingLot = ParkingLot(5)

    for (i in 1..10) {
        val carName = "Car $i"
        Thread { parkingLot.park(carName) }.start()
    }
}

class ParkingLot(spots: Int) {
    private val parkingSpots = Semaphore(spots)

    fun park(carName: String) {
        try {
            println("$carName is trying to park.")
            parkingSpots.acquire()
//            parkingSpots.tryAcquire()
            println("$carName parked.")
            Thread.sleep((Math.random() * 1000).toLong())
        } catch (e: InterruptedException) {
            e.printStackTrace()
        } finally {
            parkingSpots.release()
            println("$carName left the parking.")
        }
    }
}

