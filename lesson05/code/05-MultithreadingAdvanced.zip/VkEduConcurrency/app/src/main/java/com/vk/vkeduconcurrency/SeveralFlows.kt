package com.vk.vkeduconcurrency

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapMerge
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.zip
import kotlinx.coroutines.launch
import kotlinx.coroutines.newSingleThreadContext
import kotlinx.coroutines.runBlocking
import kotlin.random.Random

@OptIn(ExperimentalCoroutinesApi::class, DelicateCoroutinesApi::class)
fun main() {
    val battle = SeaBattle()
    runBlocking {

        battle.run()

        coroutineScope {
            combine(
                battle.numbers,
                battle.letters,
            ) { number, letter ->
                println("Next move: $letter$number")
            }.collect()

//            battle.letters.zip(battle.numbers) { number, letter ->
//                println("Next move: $letter$number")
//            }.collect()
        }
    }
}

class SeaBattle {
    val numbers = MutableSharedFlow<Int>()
    val letters = MutableSharedFlow<Char>()

    val lettersChoose = listOf('A', 'B', 'C', 'D', 'E', 'F', 'G', 'G')

    suspend fun run() {
        CoroutineScope(Dispatchers.Default).launch {
            while (true) {
                numbers.emit(Random.nextInt(1, 9))
                delay(Random.nextLong(1000))
                letters.emit(lettersChoose.random())
                delay(Random.nextLong(1000))
            }
        }
    }
}
