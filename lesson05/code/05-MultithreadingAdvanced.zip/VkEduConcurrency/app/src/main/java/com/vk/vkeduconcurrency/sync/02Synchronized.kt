package com.vk.vkeduconcurrency.sync

import com.vk.vkeduconcurrency.sync.Counter.Companion.staticSync

fun main() {
    val counter = Counter()
    println(Runtime.getRuntime().availableProcessors())
    repeat(10) {
        Thread() {
            println("${Thread.currentThread().name}: Started $it")
            repeat(20) {
                staticSync()
//                counter.increment()
                Thread.sleep(1000)
            }
        }.start()
        println("Launched $it")
    }
}

class Counter {
    @Synchronized
    fun increment() {
        println("${Thread.currentThread().name}: Start Do some work by one thread at a time")
        Thread.sleep(200)
        println("${Thread.currentThread().name}: Finish Do some work by one thread at a time")
    }

    companion object {

        fun staticSync() {
            synchronized(this) {
                println("${Thread.currentThread().name}: Start Do some work by one thread at a time")
                Thread.sleep(200)
                println("${Thread.currentThread().name}: Finish Do some work by one thread at a time")
            }
        }
    }
}


