package com.vk.vkeduconcurrency.problems

var done = false

class Worker {
    fun doWork() {
        while(!done) {
            println(1)
        }
    }
}

fun main() {
    Thread {
        Worker().doWork()
        println("Work done")
    }.start()

    val thread = Thread() {
        synchronized(78) {
            done = true
        }
    }.also {
        it.start()
    }
    thread.join()
}