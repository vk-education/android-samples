package com.vk.vkeduconcurrency

import java.util.concurrent.atomic.AtomicInteger
import kotlin.time.measureTime

/*
Что выведется на экран?
 */

class CounterDemo {

    val count = AtomicInteger(0)

    fun increment() {
        count.incrementAndGet()
    }

//    fun read() = count
//    fun write(value: Int) {
//        count = value
//    }
}

fun main() {
    val counter = CounterDemo()

    val thread1 = Thread {
        repeat(1000) {
            counter.increment()
        }
    }

    val thread2 = Thread {
        repeat(1000) {
            counter.increment()
        }
    }

    val time = measureTime {
        thread1.start()
        thread2.start()

        thread1.join()
        thread2.join()
    }

    println("Final count is ${counter.count}.\n" +
        "Time=$time")
}
