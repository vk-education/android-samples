package com.vk.vkeduconcurrency.sync

class SharedCounter {
    var count = 0
        private set

    @Synchronized
    fun increment() {
        count++
        println("Increased to: $count")
        (this as java.lang.Object).notifyAll()
    }

    @Synchronized
    fun decrement() {
        while (count == 0) {
            try {
                (this as java.lang.Object).wait()
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
        }
        count--
        println("Decreased to: $count")
    }
}

fun main() {
    val counte = SharedCounter()
    counte.increment()
    counte.decrement()
}
