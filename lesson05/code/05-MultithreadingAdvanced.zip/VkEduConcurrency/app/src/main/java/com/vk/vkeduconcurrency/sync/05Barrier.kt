package com.vk.vkeduconcurrency.sync

import java.util.concurrent.Exchanger
import kotlin.random.Random


fun main() {
    val exchanger = Exchanger<String>()
    // Producer
    Thread {
        Thread.sleep(Random.nextLong(1000))
        val received = exchanger.exchange("Hello another thread! I'm ${Thread.currentThread().name}")
        println("${Thread.currentThread().name}: received '$received'")
    }.start()

    // Processor
    Thread {
        Thread.sleep(Random.nextLong(1000))
        val received = exchanger.exchange("Hello another thread! I'm ${Thread.currentThread().name}")
        println("${Thread.currentThread().name}: received '$received'")
    }.start()
}

